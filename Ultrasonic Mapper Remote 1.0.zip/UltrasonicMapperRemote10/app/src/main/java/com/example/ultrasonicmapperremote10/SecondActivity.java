package com.example.ultrasonicmapperremote10;

import android.Manifest;
import android.content.pm.PackageManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.gridlayout.widget.GridLayout; // Required Import

import java.io.InputStream;
import java.util.UUID;

public class SecondActivity extends AppCompatActivity {

    // Standard Serial Port Profile (SPP) UUID for HC-05/HC-06
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    // TODO: Change this to your Arduino's MAC Address
    private final String DEVICE_ADDRESS = "00:11:22:AA:BB:CC";

    // Class-level variables (Fixes "cannot find symbol" errors)
    private TextView dataTextView;
    private TextView[] gridCells = new TextView[16];
    private GridLayout sensorGrid;

    private int currentCellIndex = 0;

    static {
        System.loadLibrary("ultrasonicmapperremote10");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        // 1. Link your UI components
        dataTextView = findViewById(R.id.dataOutputView);
        sensorGrid = findViewById(R.id.sensorGrid);

        // Setup the 4x4 array of cells
        for (int i = 0; i < 16; i++) {
            gridCells[i] = new TextView(this);
            gridCells[i].setText("0");
            gridCells[i].setPadding(20, 20, 20, 20);
            gridCells[i].setGravity(Gravity.CENTER);
            gridCells[i].setBackgroundResource(android.R.drawable.editbox_background);
            sensorGrid.addView(gridCells[i]);
        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // 2. CHECK THE SIGNAL FROM THE FIRST PAGE
        boolean useSimulation = getIntent().getBooleanExtra("isSimulation", false);

        if (useSimulation) {
            startBluetoothSimulation();
        } else {
            startBluetoothConnection();
        }
    }
    private void startBluetoothSimulation() {
        Handler simulationHandler = new Handler(Looper.getMainLooper());
        simulationHandler.post(new Runnable() {
            @Override
            public void run() {
                // 1. Generate the random value (10-190)
                int randomVal = 10 + (int) (Math.random() * 181);

                // 2. Process through C++
                String processed = processInNative(String.valueOf(randomVal));

                // 3. Update the cell at the CURRENT index
                gridCells[currentCellIndex].setText(processed);
                dataTextView.setText("Updating Cell: " + currentCellIndex);

                // 4. Move to the next cell (0 to 15, then reset to 0)
                currentCellIndex++;
                if (currentCellIndex >= 16) {
                    currentCellIndex = 0; // Reset to start of grid
                }
                // 5. Repeat every 500ms
                simulationHandler.postDelayed(this, 500);
            }
        });
    }
    private void startBluetoothConnection() {
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) return;

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 1);
            return;
        }

        BluetoothDevice device = adapter.getRemoteDevice(DEVICE_ADDRESS);

        new Thread(() -> {
            try {
                BluetoothSocket socket = device.createInsecureRfcommSocketToServiceRecord(MY_UUID);
                socket.connect();
                InputStream inputStream = socket.getInputStream();
                byte[] buffer = new byte[1024];

                while (true) {
                    int bytesRead = inputStream.read(buffer);
                    if (bytesRead > 0) {
                        String rawData = new String(buffer, 0, bytesRead);
                        String processedResult = processInNative(rawData);

                        new Handler(Looper.getMainLooper()).post(() -> {
                            dataTextView.setText("Arduino: " + processedResult);
                            // logic to update specific grid cells based on Arduino data would go here
                        });
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                new Handler(Looper.getMainLooper()).post(() -> {
                    dataTextView.setText("Connection Error: " + e.getMessage());
                });
            }
        }).start();
    }

    public native String processInNative(String data);
}
