package com.example.ultrasonicmapperremote10;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent; // Needed for navigation
import android.os.Bundle;
import android.view.View;
import com.example.ultrasonicmapperremote10.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    static {
        System.loadLibrary("ultrasonicmapperremote10");
    }

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // This sets the TextView to the string returned by your C++ code
        binding.textView.setText(stringFromJNI());

        // Setup the button click listener
        binding.button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // This moves the user to SecondActivity
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                intent.putExtra("isSimulation", false);
                startActivity(intent);
            }
        });

        binding.buttonSimulation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                // We add a 'true' flag to tell the second page to generate random numbers
                intent.putExtra("isSimulation", true);
                startActivity(intent);
            }
        });

    }

    public native String stringFromJNI();
}
