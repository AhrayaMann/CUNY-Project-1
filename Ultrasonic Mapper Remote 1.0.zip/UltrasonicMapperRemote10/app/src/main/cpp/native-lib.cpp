#include <jni.h>
#include <string>

// Existing function for MainActivity
extern "C" JNIEXPORT jstring JNICALL
Java_com_example_ultrasonicmapperremote10_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = " Welcome! \n This is the Ultrasonic Mapping Device Remote UI ";
    return env->NewStringUTF(hello.c_str());
}

// NEW: Function for SecondActivity to process Arduino data
extern "C" JNIEXPORT jstring JNICALL
Java_com_example_ultrasonicmapperremote10_SecondActivity_processInNative(
        JNIEnv *env,
        jobject /* this */,
        jstring data) {

    // 1. Convert Java String to C++ char*
    const char *nativeString = env->GetStringUTFChars(data, 0);

    // 2. Process data (Example: adding "cm" unit)
    // You can add mapping math here later!
    std::string result = std::string(nativeString) + " cm";

    // 3. Release the memory
    env->ReleaseStringUTFChars(data, nativeString);

    // 4. Return processed string back to the Grid
    return env->NewStringUTF(result.c_str());
}
